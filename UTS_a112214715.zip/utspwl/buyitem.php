<?php 
include "koneksi.php";
session_start();

if(!$_SESSION['login']){
    echo "<script>
             document.location.href = 'index.html';
        </script>";
} else{

    $id = $_GET["id"];
    $sql = mysqli_query($konek, "SELECT * FROM items WHERE item_id = $id");
    $row = mysqli_fetch_assoc($sql);

    #display total
   
    #user mencet tombol submit
    if(isset($_POST["submit"])){
        if(buy($konek, $_POST, $id)){
            echo "<script>
                    alert('transaksi berhasil');
                     document.location.href = 'dashboard.php';
                </script>";
        } else{
            echo "<script>
                    alert('transaksi gagal');
                    
                </script>";
        }
    }


}

#fungsi transaksi beli
function buy($conn, $value, $parameter){
    #cek apakah barang yang dibeli melebihi stock
    $sql = mysqli_query($conn, "SELECT stock FROM items WHERE item_id = '$parameter'");
    $row = mysqli_fetch_assoc($sql);
    
    if($val["qty"] > $row["stock"]){
        echo "<script>
                alert('kuantitas melebihi stock');
            </script>";
        return false;
    } 
    else{
        $qty = $row['stock'] - $value["qty"];
        $change = mysqli_query($conn, "UPDATE items SET stock = '$qty' WHERE item_id = '$parameter'");
        return true;
    }
}



?>
<html>
    <head>
       
        <link rel="stylesheet" href="buyitem.css">
    </head>
    <body>
        <div id="root">
            <h1>Check out</h1>
            <form method = "post">
             <h1 id="brand"><?php echo $row["itemName"];?></h1>
                <img src="image/<?php echo $row["foto"];?>">
               
                <input type="number" value = "1"name="qty" id="qty" min="1" max="19">
                <div id="togle">
                    <p class= "btn" id="plus" onclick="plus()">+</p>
                    <p class= "btn" id="minus" onclick="minus()">-</p>
                </div>
                <input type="number" value="<?php echo $row['price'];?>" id="total" disabled="disabled" name="total">
            <input type="submit" name="submit" id="submit" value="submit">
            </form>
        </div>
        
        <script>

            var qty = document.getElementById("qty");

            function plus(){
                if(qty.value < 19){
                    qty.value ++;
                }
            }

            function minus(){
                if(qty.value > 1){
                    qty.value --;
                }
            }

            var total = document.getElementById('total').value;
            function total(i, price){
                price *= i;
            }
            total(qty, total);


        </script>
    </body>
</html>