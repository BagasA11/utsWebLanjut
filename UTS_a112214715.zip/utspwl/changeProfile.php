<?php
include "koneksi.php";
include "libraryedit.php";
session_start();
$user_C= $_GET['username'];

if(!$_SESSION['login']){
    echo "<script>
            document.location.href = 'index.html';
        </script>";
}


#jika sudah disubmit
 if(isset($_POST['submit'])){
    if(edit($konek, $_POST, $user_C)>0){
        echo "
            <script>
                alert('profile berhasil di edit');
                document.location.href = 'dashboard.php';
            </script> ";
            
    } else{
        echo "
            <script>
                alert('profile gagal di edit');
                document.location.href = 'dashboard.php';
            </script> ";
    }
 }
?>

<html>
    <head>
        <title>Ubah profile</title>
    </head>
    <body>
        <form method="post">
            <ul>
                <li>
                    <label for="newuser">new username : </label>
                    <input type="text" name='username' id="newuser" required value = "<?php echo $_SESSION['username'];?>" autocomplete="off">
                </li>
                <li>
                    <label for="newname">nama : </label>
                    <input type="text" name="name" id="name"  required value = "<?php echo $_SESSION['name'];?>" autocomplete="off">
                </li>
                <li>
                    <label for="telp">contact : </label>
                    <input type="tel" name="telp" id="telp"  required value = "<?php echo $_SESSION['telp'];?>" autocomplete="off">
                </li>
           
                <br>
               
            <br><br>
                <input type = "submit" name="submit" value="submit">
            </ul>
        </form>

    </body>
   
</html>

