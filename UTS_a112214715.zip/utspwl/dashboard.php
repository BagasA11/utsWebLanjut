<?php 
include "koneksi.php";
session_start();
if(!$_SESSION['login']){
    echo "<script>
             document.location.href = 'index.html';
        </script>";
}

if (isset($_POST['submit'])){
    #echo $_POST['submit'];
    $username = htmlspecialchars(strtolower($_POST['username']));
   $pass = htmlspecialchars($_POST['pass']);
   if(!validate($konek, $username, $pass)){
        echo "<script>
            alert('Username atau kata sandi salah');
            document.location.href = 'index.html';
        </script>";
      #
   } else{
        #mulai session
        $_SESSION['login'] = true;
        if($_SESSION['login']){
              #fetch nilai database berdasarkan username
            $query = mysqli_query($konek, "SELECT * FROM users WHERE username = '$username'");
            
            $row = mysqli_fetch_assoc($query);
            
            $_SESSION['username'] = $row['username'];
            $_SESSION['name'] = $row['name'];
            $_SESSION['photo']  = $row['photo'];
            $_SESSION['telp'] = $row['telp'];
            
        }
   }
}

$items = mysqli_query($konek, "SELECT * FROM items");
$_SESSION['items'] = $items;

function validate($con, $data1, $pass_c){
    #cek username dan password
   $result = mysqli_query($con, "SELECT * FROM users WHERE username = '$data1'");
   $row = mysqli_fetch_assoc($result);
   #cek username
   if(mysqli_num_rows($result) === 1){
    #cek password
        
        if(password_verify($pass_c, $row['pass'])){
            echo "<script>
                    alert('Log In Berhasil');
                </script>";
            return true;
        }
        
   } else{
    return false;
   }
}
?>

<!DOCTYPE html>
<header>
    <title>dashboard</title>
    <link rel = 'stylesheet' href='dashboard.css'>
</header>

<body>
    <div class='profilecontainer'>
        <div class='photo'>
            <a href="userprofile.php" id="user"> 
                <img src='image/<?php echo $_SESSION['photo'];?>' id='userphoto'>
            </a>
            
        </div>
        <div class='name'>
            <h1><?php echo $_SESSION['username'];?></h1>
            <p><?php echo $_SESSION['name']  ;?></p>
        </div>
       
    </div>
    <div class='body'>
        <div class="upcontainer">
            <ul class="nav">
                <li class="navAct">Barang</li>
                <li><a href="itemspam.php" title="tambah barang baru">Tambah daftar barang</a></li>
                <li id="edit"><a href="changeProfile.php?username=<?= $row['username']; ?>" title="edit profile">Edit</a></li>
                <li id="logout"><a href="logout.php">LOG OUT</a></li>
            </ul>
            <form id="search" method="post">
                <input type="text" name="username">
                <input type="submit" value="search" name="submit">
            </form>
        </div>
        <article>
            <?php while($list = mysqli_fetch_assoc($_SESSION['items'])){?>
                
                <a class="itemparents" href="buyitem.php?id=<?=$list['item_id'];?>">
                    <img src="image/<?php echo $list['foto'];?>" class="ipict">
                    <h2 class="title"><?php echo $list['itemName'];?></h2>
                    <h1 class="price">RP<?php echo " " . $list['price'];?></h1>
                    <div class="stockparent">
                        <p class="str">sisa stock : </p>
                        <p class="intstock"><?php echo $list['stock'];?></p>  
                    </div>
                </a>
            
            <?php }?>
        </article>
    </div>
<script src="display.js"></script>

</body>
</html>