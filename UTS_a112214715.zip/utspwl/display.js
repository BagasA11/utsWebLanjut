let price = document.querySelector(".intstock");
let border = document.querySelector(".stockparent");

console.log(price.innerHTML);

function display(pict, frm){
    if(pict.innerHTML <= 5){
        frm.style.display = "flex";
        pict.style.color = "red";

    } else{
        frm.style.display = "none";
    }
}

display(price, border);
