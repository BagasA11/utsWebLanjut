<?php 
include "koneksi.php";
session_start();
#item table injector
if(!$_SESSION['login']){
    echo "<script>
             document.location.href = 'index.html';
        </script>";
}


?>
<!DOCTYPE html>
<html lang='en'>
    <head>
        <style></style>
        
    </head>
    <body>
        <form method='post' enctype='multipart/form-data'>
            <ul>
                <!--nama barang-->
                <li>
                    <label for='itemname'> Item Name :<label>
                    <input type='text' required name='itemName' id='itemname' autocomplete = 'off'>
                </li>
                <!--harga barang-->
                <li>
                    <label for='price'> price :<label>
                    <input type='number' required name='price' id='price' autocomplete = 'off' min='1000' max='200000'>
                </li>
            
                    <input type='hidden' name='stock' value='19'>
              
                <!-- foto barang-->
                <li>
                    <label>foto barang</label>
                    <input type='file' name='foto'>
                </li>
                <input type='submit' name='submit' value='submit'>
            </ul>
        </form>
    </body>
</html>

<?php 
if(isset($_POST['submit'])){
    if(additem($konek, $_POST)>0){
        echo '1';
        echo "<script>
                document.location.href = 'dashboard.php';
             </script>";
    }
  
} else{
    echo mysqli_error($konek);
}

function additem($conn, $data){
    $item = htmlspecialchars(stripslashes(strtolower($data['itemName'])));
   
    /*
    //check if item name isset
    if(issetitem($conn, $item)){
       echo 'udah ada';
       return false;
    }*/
    $price = $data['price'];

    //file handling
    $photo = upload();
    if(!$photo){
        return false;
    }

    #default stock item in storage
    $stock = $_POST['stock'];
    #query 
    $sql = mysqli_query($conn, "INSERT INTO items VALUES ('', '$item', '$price', '$photo', '$stock')");

    return mysqli_affected_rows($conn);

}

/*function issetitem($cn, $name) {
   
    $query_check = mysqli_query($cn, "SELECT itemName FROM items WHERE itemName = '$name'");
    
    if(mysqli_fetch_assoc($query_check)) {
        return true;
    }
}       
*/

function upload(){

    $filename = $_FILES['foto']['name'];
    $filesize = $_FILES['foto']['size'];
    $error = $_FILES['foto']['error'];
    $tmp_name = $_FILES['foto']['tmp_name'];

    if($error == 4){
        echo "<script>
                alert('pilih gambar terlebih dahulu');
            </script>";
        return false;
    }

    if($filesize > 1000000){
        echo "<script>
                alert('filesize is too much');
            </script>";
        return false;
    }
    # validate file type
    $extvalid = ['jpg', 'jpeg', 'png'];
    $ext = explode('.', $filename);
    $ext = end($ext);
    $ext = strtolower($ext);
    
    
    if(!in_array($ext, $extvalid)){
        echo "<script>
                alert('only jpg, jpeg, n png are allowed');
            </script>";
        return false;
    } 

    #generate newname
    $filename = uniqid();
    $filename .= '.' . $ext;
   
    move_uploaded_file($tmp_name, 'image/' . $filename);
    return $filename;
}

?>