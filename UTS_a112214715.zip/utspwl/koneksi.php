<?php 
// koneksi
$konek = mysqli_connect("localhost", "root", "", "utspwl");
if(!$konek) {
    echo "gagal terhubung dengan database";
}

?>
