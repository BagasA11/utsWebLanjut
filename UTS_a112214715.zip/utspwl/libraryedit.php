<?php 
function edit($conn, $value, $match){

    $newuser = htmlspecialchars(stripslashes($value['username'])) ;

    $newname = htmlspecialchars(stripslashes($value['name'])) ;

    $newtelp = $value['telp'];
    
    // encrypt code
 
    $updatesql = mysqli_query($conn, "UPDATE users SET name = '$newname', username = '$newuser' WHERE username = '$match'");
    
    return mysqli_affected_rows($conn);
}

 
/*
*/
?> 