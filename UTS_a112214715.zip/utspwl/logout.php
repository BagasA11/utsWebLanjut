<?php 
session_start();
$_SESSION = [];
session_unset();
session_destroy();
echo "
    <script>
        alert('Log out berhasil');
        document.location.href = 'index.html';
    </script>
        ";
?>