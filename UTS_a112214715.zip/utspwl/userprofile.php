<?php 

include "koneksi.php";
session_start();
if(!$_SESSION['login']){
    echo "<script>
             document.location.href = 'index.html';
        </script>";
}

$username = $_SESSION['username'];
echo $username;

if(isset($_POST['submit'])){
    if(ubahfoto($konek, $username)){
        echo "<script>
                alert('foto berhasil diubah');
                document.location.href = 'dashboard.php';
            </script>";
    } else{
        echo "<script>
                alert('foto gagal diubah');
                document.location.href = 'dashboard.php';
            </script>";
    }
   
}

function ubahfoto($conn, $pair){
    $newphoto = upload();
    if(!$newphoto){
        return false;
    }
    $sql = mysqli_query($conn, "UPDATE users SET photo = '$newphoto' WHERE username = '$pair'");
    return true;
}

function upload(){
    $filename = $_FILES['photo']['name'];
    $filesize = $_FILES['photo']['size'];
    $error = $_FILES['photo']['error'];
    $tmp_name = $_FILES['photo']['tmp_name'];
    
    if($filesize > 1000000){
        echo "<script>
                alert('filesize is too much');
            </script>";
        return false;
    } 
   
    # validate file type
    $extvalid = ['jpg', 'jpeg', 'png'];
    $ext = explode('.', $filename);
    $ext = end($ext);
    $ext = strtolower($ext);
    
    
    if(!in_array($ext, $extvalid)){
        echo "<script>
                alert('only jpg, jpeg, n png are allowed');
            </script>";
        return false;
    } 

    #generate newname
    $filename = uniqid();
    $filename .= '.' . $ext;
   
    move_uploaded_file($tmp_name, 'image/' . $filename);
    return $filename;
}
?>
<html>
    <head></head>
    <body>
        <form method = "post" enctype = "multipart/form-data">
            <input type="file" name = "photo">
           <input type="submit" name="submit" value="submit">
        </form>
    </body>
    
</html>