-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 08, 2023 at 01:11 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `utspwl`
--

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `item_id` int(11) NOT NULL,
  `itemName` varchar(100) NOT NULL,
  `price` double NOT NULL,
  `foto` varchar(200) NOT NULL,
  `stock` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`item_id`, `itemName`, `price`, `foto`, `stock`) VALUES
(1, 'Bunga', 10000, 'bunga.jpg', 14),
(2, 'bunga', 10000, 'bunga.jpg', 19),
(3, 'pensil warna fabel castel  12pcs', 20000, '6455ff923e68e.jpg', 0),
(4, 'penggaris segitiga', 10000, '645600660f400.jpg', 0),
(5, 'bucket bunga', 50000, '645600dc80db6.jpg', 19),
(6, 'bunga', 10000, '64564c39b9541.jpg', 19),
(8, 'gambar pulau', 2000, '64585c9f1e006.jpg', 14);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_Id` int(11) NOT NULL,
  `name` varchar(60) NOT NULL,
  `username` varchar(80) NOT NULL,
  `telp` varchar(25) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `photo` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_Id`, `name`, `username`, `telp`, `pass`, `photo`) VALUES
(1, 'Bagas Rayhan', 'bagas321', '0221475112', '$2y$10$riY2CaBp.n/07u/sNz9dg.ff4nA7t/3C.69aFv76DgRRZprppvXea', 'nophoto.jpg'),
(2, 'Bagas Rayhan', 'bagasrs111', '081312892783', '$2y$10$jJipUGi2EmYWRR5nCtrt1.EUCi8xBz8.eF1ud.sofbo3WySssI45W', 'nophoto.jpg'),
(6, 'Bagas Rayhan', 'gass', '08221879273', '$2y$10$9W21Ful7zOkjr/tfSzXDAeObPhrDpTtA1sQa0AFD.KhVJQfG4LR86', 'nophoto.jpg'),
(7, 'Bagas RS', 'bagas1a1', '082112897283', '$2y$10$UnRDS9mB98vSshDXPJ1PTOmal2F2rARPW6R4wCltKy5jrcv.N49P.', '6457c6aac4c24.jpeg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`item_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
